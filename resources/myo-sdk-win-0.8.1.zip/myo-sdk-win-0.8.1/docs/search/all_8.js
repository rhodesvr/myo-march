var searchData=
[
  ['normalized',['normalized',['../classmyo_1_1_quaternion.html#a64a28d8f03ae7b391c242489f2b30146',1,'myo::Quaternion::normalized()'],['../classmyo_1_1_vector3.html#aab8aebef9595d601b9e15f4290442ee8',1,'myo::Vector3::normalized()']]],
  ['notifyuseraction',['notifyUserAction',['../classmyo_1_1_myo.html#ac54c392d495c2824149c0ff69cd63633',1,'myo::Myo']]]
];
