var searchData=
[
  ['removelistener',['removeListener',['../classmyo_1_1_hub.html#a86c064cb1c6b93f8ce2c4f61b2efe056',1,'myo::Hub']]],
  ['requestrssi',['requestRssi',['../classmyo_1_1_myo.html#a38477309f70709e2bf1d3d1a82d30e00',1,'myo::Myo']]],
  ['rotate',['rotate',['../classmyo_1_1_quaternion.html#a23b8c84385a2486f37abd14a07ee6c65',1,'myo::Quaternion::rotate(const Quaternion&lt; T &gt; &amp;quat, const Vector3&lt; T &gt; &amp;vec)'],['../classmyo_1_1_quaternion.html#ab2bc198ec59e5e8a29b1ea4445a67f7d',1,'myo::Quaternion::rotate(const Vector3&lt; T &gt; &amp;from, const Vector3&lt; T &gt; &amp;to)']]],
  ['run',['run',['../classmyo_1_1_hub.html#ad72dfa5120fe877104c38d8d29a097f9',1,'myo::Hub']]],
  ['runonce',['runOnce',['../classmyo_1_1_hub.html#a6e1985b9b59dbcf5034297140cad637e',1,'myo::Hub']]]
];
